package acgs.compliance.hipaa

# HIPAA Compliance Policy
# Constitutional Hash: cdd01ef066bc6cf2

default allow = false

allow {
    input.action == "access_phi"
    input.user_role in ["doctor", "nurse", "admin"]
    input.access_purpose in ["treatment", "payment", "operations"]
}

allow {
    input.action == "store_phi"
    input.storage_encryption == true
    input.storage_encryption_standard == "AES-256"
}
