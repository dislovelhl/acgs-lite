package acgs.compliance.gdpr

# GDPR Compliance Policy
# Constitutional Hash: cdd01ef066bc6cf2

default allow = false

allow {
    input.action == "process_personal_data"
    input.consent_obtained == true
    input.consent_informed == true
}

allow {
    input.action == "export_data"
    input.format in ["json", "csv"]
}
